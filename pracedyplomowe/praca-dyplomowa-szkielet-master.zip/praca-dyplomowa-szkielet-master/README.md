## Szkielet pracy dyplomowej w LaTeX

## Kompilacja
* Plikiem startowym jest Start.tex
* Szkielet utworzony w programie Kile pod systemem Ubuntu 12.04 LTS
* Nalezy skompilowac przed pierwsza edycja
